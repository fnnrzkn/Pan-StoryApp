package com.irfannurrizki.panstoryapp.appdata.localdata.applocaldatabase;public @interface Generated {
}
