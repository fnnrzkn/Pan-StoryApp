package com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession

class AppAddStoryViewModel (private val pref: AppUserSession) : ViewModel() {
    fun getUserToken(): LiveData<String> {
        return pref.getUserToken().asLiveData()
    }
}