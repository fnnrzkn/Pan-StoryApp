package com.irfannurrizki.panstoryapp.appuserinterface.appactivity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.RegisterResponse
import com.irfannurrizki.panstoryapp.appdata.serverdata.apisetting.AppApiConfig
import com.irfannurrizki.panstoryapp.appuserinterface.appcustomview.CustomEmailEditText
import com.irfannurrizki.panstoryapp.appuserinterface.appcustomview.CustomNameEditText
import com.irfannurrizki.panstoryapp.appuserinterface.appcustomview.CustomPasswordEditText
import com.irfannurrizki.panstoryapp.databinding.ActivityAppRegisterBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AppRegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppRegisterBinding
    private lateinit var customEmailEditText: CustomEmailEditText
    private lateinit var customPasswordEditText: CustomPasswordEditText
    private lateinit var customNameEditText: CustomNameEditText

    private var correctEmail: Boolean = false
    private var correctPassword: Boolean = false
    private var correctName: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        binding = ActivityAppRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        playAnimation()

        val registButton = binding.registButton
        customEmailEditText = binding.etEmailinput
        customPasswordEditText = binding.etPasswordinput
        customNameEditText = binding.etNameinput

       customNameEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s != null) {
                    correctName = s.length >= 2
                }
                registButton.isEnabled = correctName && correctEmail && correctPassword
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })

        customEmailEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                correctEmail =
                    !s.isNullOrEmpty() && AppLoginActivity.emailRegex.matches(s.toString())
                registButton.isEnabled = correctName && correctEmail && correctPassword
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })

        customPasswordEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                correctPassword = !(!s.isNullOrEmpty() && s.length < 6)
                registButton.isEnabled = correctName && correctEmail && correctPassword
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        registButton.setOnClickListener {
            register()
        }

        binding.tvHaveaccount.setOnClickListener {
            val i = Intent(this, AppLoginActivity::class.java)
            startActivity(i)
            finish()
        }
    }

    private fun register() {
        showLoading(true)
        val client = AppApiConfig.getAppApiService().register(
            customNameEditText.text.toString(),
            customEmailEditText.text.toString(),
            customPasswordEditText.text.toString()
        )
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    if (responseBody.error == true) {
                        showLoading(false)
                        Toast.makeText(
                            this@AppRegisterActivity,
                            responseBody.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        goLogin()
                        Toast.makeText(
                            this@AppRegisterActivity,
                            responseBody.message,
                            Toast.LENGTH_LONG
                        )
                            .show()
                    }
                } else {
                    showLoading(false)
                    Log.e(ContentValues.TAG, "onFailure: ${response.message()},${response.code()}")
                    Toast.makeText(this@AppRegisterActivity, response.message(), Toast.LENGTH_LONG)
                        .show()
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                showLoading(false)
                Log.e(ContentValues.TAG, "onFailure: ${t.message}")
                Toast.makeText(this@AppRegisterActivity, t.message, Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun playAnimation() {
        val tvRegisterBar = ObjectAnimator.ofFloat(binding.tvRegisterbar, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val tvNameColumn = ObjectAnimator.ofFloat(binding.tvNamecolumn, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val etNameInput = ObjectAnimator.ofFloat(binding.etNameinput, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val tvEmailColumn = ObjectAnimator.ofFloat(binding.tvEmailcolumn, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val etEmailInput = ObjectAnimator.ofFloat(binding.etEmailinput, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val tvPasswordColumn = ObjectAnimator.ofFloat(binding.tvPasswordcolumn, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val etPasswordInput = ObjectAnimator.ofFloat(binding.etPasswordinput, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val registButton = ObjectAnimator.ofFloat(binding.registButton, View.ALPHA, ALPHA).setDuration(
            DURATION
        )
        val tvHaveAccount = ObjectAnimator.ofFloat(binding.tvHaveaccount, View.ALPHA, ALPHA).setDuration(
            DURATION
        )

        AnimatorSet().apply {
            playSequentially(
                tvRegisterBar,
                tvNameColumn,
                etNameInput,
                tvEmailColumn,
                etEmailInput,
                tvPasswordColumn,
                etPasswordInput,
                registButton,
                tvHaveAccount
            )
            start()
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.apply {
            visibility = if (isLoading) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }
    }

    private fun goLogin() {
        val i = Intent(this, AppLoginActivity::class.java)
        i.putExtra("email", customEmailEditText.text.toString())
        i.putExtra("password", customPasswordEditText.text.toString())
        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(i)
        showLoading(false)
        finish()
    }

    companion object {
        private const val DURATION = 200L
        private const val ALPHA = 1f
    }
}