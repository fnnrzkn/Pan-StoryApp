package com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession
import kotlinx.coroutines.launch

class AppLoginViewModel (private val pref: AppUserSession) : ViewModel() {
    fun getToken(): LiveData<String> {
        return pref.getUserToken().asLiveData()
    }

    fun saveToken(token: String) {
        viewModelScope.launch {
            pref.saveUserToken(token)
        }
    }
}