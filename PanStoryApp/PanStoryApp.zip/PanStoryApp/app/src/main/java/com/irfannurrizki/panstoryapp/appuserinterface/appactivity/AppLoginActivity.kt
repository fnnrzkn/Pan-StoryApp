package com.irfannurrizki.panstoryapp.appuserinterface.appactivity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.LoginResponse
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.LoginResult
import com.irfannurrizki.panstoryapp.appdata.serverdata.apisetting.AppApiConfig
import com.irfannurrizki.panstoryapp.appuserinterface.appcustomview.CustomEmailEditText
import com.irfannurrizki.panstoryapp.appuserinterface.appcustomview.CustomPasswordEditText
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppLoginViewModel
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppViewModelFactory
import com.irfannurrizki.panstoryapp.databinding.ActivityAppLoginBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AppLoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppLoginBinding
    private lateinit var customEmailEditText: CustomEmailEditText
    private lateinit var customPasswordEditText: CustomPasswordEditText

    private lateinit var appLoginViewModel: AppLoginViewModel

    private var correctEmail = false
    private var correctPassword = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        binding = ActivityAppLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        playAnimation()

        val loginButton = binding.loginButton
        customEmailEditText = binding.etEmailinput
        customPasswordEditText = binding.etPasswordinput

        val pref = AppUserSession.getInstance(dataStore)

        if (!intent.getStringExtra("email").isNullOrEmpty()) {
            customEmailEditText.setText(intent.getStringExtra("email"))
            correctEmail = true
        }
        if (!intent.getStringExtra("password").isNullOrEmpty()) {
            customPasswordEditText.setText(intent.getStringExtra("password"))
            correctPassword = true
        }

        appLoginViewModel = ViewModelProvider(
            this,
            AppViewModelFactory(pref)
        )[AppLoginViewModel::class.java]

        fun setLoginButtonEnable() {
            loginButton.isEnabled = correctEmail && correctPassword
        }

        customEmailEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                correctEmail =
                    !s.isNullOrEmpty() && emailRegex.matches(s.toString())
                setLoginButtonEnable()
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })

        customPasswordEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                correctPassword = !(!s.isNullOrEmpty() && s.length < 8)
                setLoginButtonEnable()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        loginButton.setOnClickListener {
            loginResponse()
        }

        binding.tvHaventaccount.setOnClickListener {
            val i = Intent(this, AppRegisterActivity::class.java)
            startActivity(i)
            finish()
        }
    }

    private fun playAnimation() {
        val tvwelcomeLogin =
            ObjectAnimator.ofFloat(binding.tvWelcomelogin, View.ALPHA, ALPHA).setDuration(DURATION)
        val tvemailColumn =
            ObjectAnimator.ofFloat(binding.tvEmailcolumn, View.ALPHA, ALPHA).setDuration(DURATION)
        val etemailInput =
            ObjectAnimator.ofFloat(binding.etEmailinput, View.ALPHA, ALPHA).setDuration(DURATION)
        val tvpasswordColumn=
            ObjectAnimator.ofFloat(binding.tvPasswordcolumn, View.ALPHA, ALPHA).setDuration(DURATION)
        val etpasswordInput =
            ObjectAnimator.ofFloat(binding.etPasswordinput, View.ALPHA, ALPHA).setDuration(DURATION)
        val loginButton =
            ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, ALPHA).setDuration(DURATION)
        val tvhaventAccount =
            ObjectAnimator.ofFloat(binding.tvHaventaccount, View.ALPHA, ALPHA).setDuration(DURATION)

        AnimatorSet().apply {
            playSequentially(
                tvwelcomeLogin,
                tvemailColumn,
                etemailInput,
                tvpasswordColumn,
                etpasswordInput,
                loginButton,
                tvhaventAccount
            )
            start()
        }
    }

    private fun loginResponse() {
        showLoading(true)
        val client = AppApiConfig.getAppApiService()
            .login(customEmailEditText.text.toString(), customPasswordEditText.text.toString())
        client.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    if (responseBody.error == true) {
                        showLoading(false)
                        Toast.makeText(this@AppLoginActivity, responseBody.message, Toast.LENGTH_LONG)
                            .show()
                    } else {
                        saveSession(responseBody.loginResult as LoginResult)
                        Toast.makeText(
                            this@AppLoginActivity,
                            getString(R.string.login_granted),
                            Toast.LENGTH_LONG
                        )
                            .show()
                    }
                } else {
                    showLoading(false)
                    Log.e(ContentValues.TAG, "onFailure: ${response.message()}")
                    Toast.makeText(this@AppLoginActivity, response.message(), Toast.LENGTH_LONG)
                        .show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                showLoading(false)
                Log.e(ContentValues.TAG, "onFailure: ${t.message}")
                Toast.makeText(this@AppLoginActivity, t.message, Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.apply {
            visibility = if (isLoading) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }
    }

    private fun saveSession(loginResult: LoginResult) {
        showLoading(false)
        appLoginViewModel.saveToken(loginResult.token as String)
        val i = Intent(this, AppMainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(i)
        finish()
    }

    companion object {
        private const val DURATION = 250L
        private const val ALPHA = 2f
        val emailRegex: Regex = Regex("^\\w+([.-]?\\w+)*@\\w+([.-]?\\w+)*(\\.\\w{2,3})+\$")
    }
}