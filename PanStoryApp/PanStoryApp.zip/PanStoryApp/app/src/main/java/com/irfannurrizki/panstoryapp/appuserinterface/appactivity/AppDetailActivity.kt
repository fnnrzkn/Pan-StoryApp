package com.irfannurrizki.panstoryapp.appuserinterface.appactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.ListStoryItem
import com.irfannurrizki.panstoryapp.databinding.ActivityAppDetailBinding

class AppDetailActivity:AppCompatActivity() {

    private lateinit var detailStories: ListStoryItem
    private lateinit var binding: ActivityAppDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        detailStories = intent.getParcelableExtra <ListStoryItem>(STORIES) as ListStoryItem
        binding.apply {
            tvStorydetailName.text = detailStories.name
            tvStorydetailDescription.text = detailStories.description
        }
        Glide.with(applicationContext)
            .load(detailStories.photoUrl)
            .into(binding.imStorydetailPhoto)
    }

    companion object {
        const val STORIES = "stories"
    }
}
