package com.irfannurrizki.panstoryapp.appuserinterface.appactivity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.ListStoryItem
import com.irfannurrizki.panstoryapp.appuserinterface.appadapter.AppListStoryAdapter
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppMainViewModel
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppViewModelFactory
import com.irfannurrizki.panstoryapp.databinding.ActivityMainBinding

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class AppMainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var appMainViewModel: AppMainViewModel
    private lateinit var arrayListStory: ArrayList<ListStoryItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref = AppUserSession.getInstance(dataStore)

        appMainViewModel = ViewModelProvider(this, AppViewModelFactory(pref))[AppMainViewModel::class.java]

        appMainViewModel.getUserToken().observe(
            this
        ) { token: String ->
            if (token.isEmpty()) {
                val i = Intent(this, AppLoginActivity::class.java)
                startActivity(i)
                finish()
            } else {
                appMainViewModel.getAllStoryResponse(token)
            }
        }

        appMainViewModel.listStories.observe(this) { listStories ->
            showRecyclerList(listStories)
        }
        appMainViewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    override fun onBackPressed() {
        val a = Intent(Intent.ACTION_MAIN)
        a.addCategory(Intent.CATEGORY_HOME)
        a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(a)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.feature_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.language_feature -> {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
                return true
            }
            R.id.add_feature -> {
                val i = Intent(this, AppAddStoryActivity::class.java)
                startActivity(i)
                return true
            }
            R.id.logout_feature -> {
                appMainViewModel.saveUserToken("")
                val i = Intent(this, AppLoginActivity::class.java)
                i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(i)
                return true
            }
            else -> return true
        }
    }

    private fun showRecyclerList(listStories: List<ListStoryItem>) {
        binding.apply {
            rvStories.setHasFixedSize(true)

            if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                rvStories.layoutManager = GridLayoutManager(this@AppMainActivity, 4)
            else
                rvStories.layoutManager = GridLayoutManager(this@AppMainActivity, 2)

            arrayListStory = ArrayList()
            arrayListStory.addAll(listStories)
            val appListStoryAdapter = AppListStoryAdapter(arrayListStory)
            rvStories.adapter = appListStoryAdapter
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.apply {
            visibility = if (isLoading) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }
    }

    companion object {
        const val ARRAY_LIST_STORIES = "array_list_stories"
    }
}