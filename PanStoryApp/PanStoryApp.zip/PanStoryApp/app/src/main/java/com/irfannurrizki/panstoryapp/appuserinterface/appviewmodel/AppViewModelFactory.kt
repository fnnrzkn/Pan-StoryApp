package com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession

class AppViewModelFactory (private val pref: AppUserSession) : ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(AppMainViewModel::class.java) -> {
                AppMainViewModel(pref) as T
            }
            modelClass.isAssignableFrom(AppLoginViewModel::class.java) -> {
                AppLoginViewModel(pref) as T
            }
            modelClass.isAssignableFrom(AppAddStoryViewModel::class.java) -> {
                AppAddStoryViewModel(pref) as T
            }
            else -> throw IllegalArgumentException("Unknown Viewmodel Class: " + modelClass.name)
        }
    }

}