package com.irfannurrizki.panstoryapp.appuserinterface.appadapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.ListStoryItem
import com.irfannurrizki.panstoryapp.appuserinterface.appactivity.AppDetailActivity

class AppListStoryAdapter (private val listStories: ArrayList<ListStoryItem>) :
    RecyclerView.Adapter<AppListStoryAdapter.ListViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.story_item, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(listStories[position])
    }

    override fun getItemCount(): Int = listStories.size

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private var imgPhoto: ImageView = itemView.findViewById(R.id.im_story_photo)
        private var tvUsername: TextView = itemView.findViewById(R.id.tv_story_name)
        private var tvDescription: TextView = itemView.findViewById(R.id.tv_story_description)

        fun bind(stories: ListStoryItem) {
            tvUsername.text = stories.name
            tvDescription.text = stories.description
            Glide.with(itemView.context).load(stories.photoUrl).into(imgPhoto)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, AppDetailActivity::class.java)
                intent.putExtra(STORIES, stories)

                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        Pair(imgPhoto, "profile"),
                        Pair(tvUsername, "name"),
                        Pair(tvDescription, "description"),
                    )
                itemView.context.startActivity(intent, optionsCompat.toBundle())
            }
        }
    }
    companion object {
        const val STORIES = "stories"
    }
}