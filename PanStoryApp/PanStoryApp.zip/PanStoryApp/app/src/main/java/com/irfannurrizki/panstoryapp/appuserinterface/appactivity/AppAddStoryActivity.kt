package com.irfannurrizki.panstoryapp.appuserinterface.appactivity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.irfannurrizki.panstoryapp.R
import com.irfannurrizki.panstoryapp.appdata.localdata.AppUserSession
import com.irfannurrizki.panstoryapp.appdata.serverdata.apiresponse.AddNewStoryResponse
import com.irfannurrizki.panstoryapp.appdata.serverdata.apisetting.AppApiConfig
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppAddStoryViewModel
import com.irfannurrizki.panstoryapp.appuserinterface.appviewmodel.AppViewModelFactory
import com.irfannurrizki.panstoryapp.databinding.ActivityAppAddStoryBinding
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class AppAddStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppAddStoryBinding
    private lateinit var appAddStoryViewModel: AppAddStoryViewModel


    private var getFile: File? = null

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            getFile = myFile

            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            myFile?.let { file ->
                rotateFile(file, isBackCamera)
                binding.ivAddstorypreview.setImageBitmap(BitmapFactory.decodeFile(file.path))
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri
            val myFile = uriToFile(selectedImg, this@AppAddStoryActivity)
            getFile = myFile
            binding.ivAddstorypreview.setImageURI(selectedImg)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    getString(R.string.permission_failed),
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref = AppUserSession.getInstance(dataStore)
        appAddStoryViewModel =
            ViewModelProvider(this, AppViewModelFactory(pref))[AppAddStoryViewModel::class.java]

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        binding.edittextDescription.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!s.isNullOrBlank()) {
                    binding.btUpload.isEnabled = true
                } else {
                    binding.btUpload.isEnabled = false
                    binding.edittextDescription.error = getString(R.string.fill_required)
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
        binding.btCamerax.setOnClickListener { val intent = Intent(this, AppCameraActivity::class.java)
            launcherIntentCameraX.launch(intent) }

        binding.btGallery.setOnClickListener { val intent = Intent()
            intent.action = Intent.ACTION_GET_CONTENT
            intent.type = "image/*"
            val chooser = Intent.createChooser(intent, getString(R.string.select_pitcure))
            launcherIntentGallery.launch(chooser)}

        binding.btUpload.setOnClickListener { uploadImage() }


    }


    private fun uploadImage() {
        if (getFile != null) {
            val file = reduceFileImage(getFile as File)
            val description =
                binding.edittextDescription.text.toString().toRequestBody("text/plain".toMediaType())


            val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                "photo",
                file.name,
                requestImageFile
            )

            appAddStoryViewModel.getUserToken().observe(
                this
            ) { token: String ->
                val service = AppApiConfig.getAppApiService()
                    .uploadStories("Bearer $token", imageMultipart, description)
                showLoading(true)
                service.enqueue(object : Callback<AddNewStoryResponse> {
                    override fun onResponse(
                        call: Call<AddNewStoryResponse>,
                        response: Response<AddNewStoryResponse>
                    ) {
                        if (response.isSuccessful) {
                            showLoading(false)
                            val responseBody = response.body()
                            if (responseBody != null && !responseBody.error!!) {
                                Toast.makeText(
                                    this@AppAddStoryActivity,
                                    responseBody.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                                intentMain()
                            }
                        } else {
                            showLoading(false)
                            Toast.makeText(
                                this@AppAddStoryActivity,
                                response.message(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(call: Call<AddNewStoryResponse>, t: Throwable) {
                        showLoading(false)
                        Toast.makeText(
                            this@AppAddStoryActivity,
                            getString(R.string.retrofit_failure),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
            }
        } else {
            Toast.makeText(
                this@AppAddStoryActivity,
                getString(R.string.choose_image),
                Toast.LENGTH_SHORT
            ).show()
        }
    }


    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.apply {
            visibility = if (isLoading) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }
    }

    private fun intentMain() {
        val i = Intent(this, AppMainActivity::class.java)
        startActivity(i)
        showLoading(false)
        finish()
    }

    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        const val CAMERA_X_RESULT = 200

        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}